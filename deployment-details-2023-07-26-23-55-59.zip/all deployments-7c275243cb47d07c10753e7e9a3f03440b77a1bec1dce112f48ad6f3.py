import json
import os
import csv
'''
    print('Collect first two thousand deployments')    
    print('**Grep the csv formatted report from log')
'''    
    
file_name = '/root/web-root/data.csv'
file_name2 = '/root/web-root/data2.csv'

def handler(context, inputs):
    url = '/blueprint/api/blueprints?$select=name,blueprintId'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
    t = json_resp['totalElements']
    content = json_resp['content']
    blueprints = {}
    for item in content:
        id = item['id']
        name = item['name']
        #print(id + '; ' + name)
        blueprints[id] = name
    print("No of blueprints: " + str(t))
    print(blueprints)  
    
    url = '/deployment/api/deployments?$top=2000&$skip=0' # first 1000 deployments
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
        return outputs
    t = json_resp['totalElements']
    content = json_resp['content']
    deployments = {}
    for item in content:
        id = item['id']
        name = item['name']
        #print(id + '; ' + name)
        deployments[id] = name
    print("No of deployments: " + str(t))
    print(deployments)
    report = []
    os.mkdir('/root/web-root') 
    for k, v in deployments.items():
        data = deploymentDetail(context, k)
        report = report + data
        print("deployment: " + k + "; name: " + v + "; actions: " + str(len(data)))
       
    generateCSV(report)
    replaceIds(deployments)
    replaceIds(blueprints)
    '''
    command = "sed '2~2d' " + file_name + " > " + file_name2 # remove even numbered lines that are blank
    print(command)
    os.system(command)
    '''
    readFile(file_name)
    outputs = {
      "totalDeployments": t,
      "report": report
    }
    return outputs

def replaceIds(deployments):
    for k, v in deployments.items():
        id = k
        name = v
        command = "sed 's/" +  id + '/"' + name + '"' + "/' " + file_name + ' > ' + file_name2
        #print(command)
        os.system(command)
        command = "mv " + file_name2 + " " + file_name
        os.system(command)
    return
    
def readFile(fileName):
        fileHandler = open(fileName,"r")
        text = fileHandler.read()
        fileHandler.close()
        print(fileName,'content')
        print(text)
        return text

def generateCSV(array):  
    fieldnames = []
    for j in range(len(array)):    
        keys = array[j].keys()
        for i in keys:
            if (i not in fieldnames):
                fieldnames.append(i)
    print(fieldnames)
    
    # file_name = '/root/web-root/data.csv'
    # create a CSV file and write the data
    with open(file_name, 'w', newline='') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames)
        writer.writeheader()
        for row in array:
            writer.writerow(row)
    return 

def deploymentDetail(context, deploymentId):  
    outputs = {}
    
    url = '/deployment/api/deployments/' + deploymentId + '/requests?$top=200&$skip=0'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
        return outputs
    t = json_resp['totalElements']
    content = json_resp['content']
    return content
